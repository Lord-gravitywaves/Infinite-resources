# source_mod
Provides blocks that supply infinite resources, liquids, and power.

<br>

**WARNING:**

Provides blocks that supply infinite resources, liquids, and power.

<br>

**Feature List:**

0. Item sources are available at the cost of 1 copper each.

1. Liquid sources are available at the cost of 1 copper each.

2. Sources for unlimited energy (power) are available at the cost of 1 copper each.


**End of list.**
